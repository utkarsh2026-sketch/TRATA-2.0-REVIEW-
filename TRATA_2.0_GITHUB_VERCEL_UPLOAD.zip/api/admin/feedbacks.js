import crypto from "crypto";

function verifyToken(token, secret) {
  try {
    const [payload, sig] = String(token || "").split(".");
    if (!payload || !sig) return false;
    const expected = crypto.createHmac("sha256", secret).update(payload).digest("hex");
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    return data.exp > Date.now();
  } catch {
    return false;
  }
}

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ ok:false });

  const secret = process.env.ADMIN_SECRET;
  const cookies = req.headers.cookie || "";
  const token = cookies.split(";").map(x => x.trim()).find(x => x.startsWith("trata_admin="))?.split("=")[1];

  if (!secret || !verifyToken(token, secret)) {
    return res.status(401).json({ ok:false, error:"Unauthorized" });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SECRET_KEY;
  if (!url || !key) return res.status(500).json({ ok:false, error:"Supabase environment variables are missing." });

  const r = await fetch(`${url}/rest/v1/feedbacks?select=*&order=id.desc`, {
    headers: { apikey:key, Authorization:`Bearer ${key}` }
  });

  if (!r.ok) return res.status(500).json({ ok:false, error: await r.text() });
  return res.status(200).json({ ok:true, feedbacks: await r.json() });
}
