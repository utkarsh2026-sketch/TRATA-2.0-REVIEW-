export default async function handler(req, res) {
  res.setHeader("Set-Cookie", "trata_admin=; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=0");
  return res.status(200).json({ ok:true });
}
