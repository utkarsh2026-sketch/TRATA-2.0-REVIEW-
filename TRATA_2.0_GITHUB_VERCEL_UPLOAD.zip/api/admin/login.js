import crypto from "crypto";

function cookie(name, value, maxAge) {
  return `${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=${maxAge}`;
}
function sign(value, secret) {
  return crypto.createHmac("sha256", secret).update(value).digest("hex");
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok:false });

  const body = req.body || {};
  const username = String(body.username || "");
  const password = String(body.password || "");

  const expectedUser = process.env.ADMIN_USERNAME || "Trata";
  const expectedPass = process.env.ADMIN_PASSWORD || "sunbeam123";
  const secret = process.env.ADMIN_SECRET;

  if (!secret) return res.status(500).json({ ok:false, error:"ADMIN_SECRET is not configured." });

  if (username !== expectedUser || password !== expectedPass) {
    return res.status(401).json({ ok:false, error:"Invalid credentials" });
  }

  const payload = Buffer.from(JSON.stringify({ u: username, exp: Date.now() + 8*60*60*1000 })).toString("base64url");
  const token = `${payload}.${sign(payload, secret)}`;

  res.setHeader("Set-Cookie", cookie("trata_admin", token, 8*60*60));
  return res.status(200).json({ ok:true });
}
